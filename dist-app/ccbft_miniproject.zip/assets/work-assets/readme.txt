接口地址：http://apps.topcode.cloud:9102/mock/101/getInfo
