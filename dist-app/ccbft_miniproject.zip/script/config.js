/**
 * 扩展api配置
 */
window.JumpConf = null
window.JumpConf && window.JumpConf.extApi && (window.JumpExtApiConf = window.JumpConf.extApi)
